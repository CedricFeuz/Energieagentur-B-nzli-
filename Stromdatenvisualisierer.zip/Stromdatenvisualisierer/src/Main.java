import control.Manager;

public class Main {

	public static void main(String[] args) {
		Manager m = new Manager();
		m.openStartGui();
	}
}
