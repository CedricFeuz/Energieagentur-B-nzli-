package view;

/**
* Teilweise mit GUIGenie generiert
* @author  Clarissa Sullivan
* @version 1.0
* @date   02.10.2019
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import control.Manager;

public class ErfolgGui extends JFrame {
	private JLabel success;
	private JButton zurueckButton;

	private JFrame frame;
	private Manager vm;

	public ErfolgGui(JFrame frame, Manager vm) {

		this.frame = frame;
		this.vm = vm;

		success = new JLabel("Export erfolgreich.");
		zurueckButton = new JButton("Zur�ck");

	}

	public void erfolgGui() {
		setPreferredSize(new Dimension(944, 574));
		setLayout(null);

		add(success);
		add(zurueckButton);

		success.setBounds(406, 240, 115, 35);
		zurueckButton.setBounds(370, 310, 175, 40);

		JFrame windowFrame = new JFrame("MyPanel");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().add(new ExportierenGui(windowFrame, vm));
		frame.pack();
		frame.setVisible(true);
	}

}
