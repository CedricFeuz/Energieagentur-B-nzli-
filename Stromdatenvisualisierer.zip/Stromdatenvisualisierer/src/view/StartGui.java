package view;
/**
*Teilweise mit GUIGenie generiert
* @author  Clarissa Sullivan, Alexandra Wittwer
* @version 1.1
* @since   30.09.2019
* 
* Diese Klasse ist dazu zust�ndig, die Maske vom StartMenu anzuzeigen.
*/

import java.awt.*;
import java.awt.event.*;
import java.io.File;

import javax.swing.*;
import control.Manager;

public class StartGui extends JFrame {
	//VARIABELN DEKLARIEREN
	private JFrame frame;
	private Manager vm;
	//Komponente
	private JButton tagesvbd, jahresvbd, zaehlerstandd;
	private JButton importbutton, exportbutton;
	private JLabel copyrighttext, image, titel;

	private static boolean exception;

	public StartGui(JFrame frame, Manager vm) {
		//instatzieren
		this.frame = frame;
		this.vm = vm;

		exception = true;
		
	}

	
	public void gui() {
		//Schriftarten erstellen
		Font schriftart = new Font("Arial", Font.BOLD, 60);
		Font schriftart2 = new Font("Arial", Font.PLAIN, 20);
		//Hintergrund einsetzen
		File test = new File("");
		String fi = test.getAbsolutePath() + "\\background.jpeg";
		frame.setLayout(new BorderLayout());
		frame.setContentPane(new JLabel(new ImageIcon(fi)));
		//Erstellung der Komponenten
		tagesvbd = new JButton("Tagesverbrauchsdiagramm");
		jahresvbd = new JButton("Jahresverbrauchsdiagramm");
		zaehlerstandd = new JButton("Z�hlerstanddiagramm");
		importbutton = new JButton("Importieren");
		exportbutton = new JButton("Exportieren");
		copyrighttext = new JLabel("Stromdatenvisualisierer Version 1.0. Alle Rechte vorbehalten.");
		titel = new JLabel("Stromdatenvisualisierer");
		
		//Fensterdarstellung
		frame.setTitle("Start Menu");
		frame.setPreferredSize(new Dimension(944, 600));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setPreferredSize(new Dimension(944, 600));
		//Schriftarten an den Komponenten hinzuf�gen
		titel.setFont(schriftart);
		tagesvbd.setFont(schriftart2);
		jahresvbd.setFont(schriftart2);
		zaehlerstandd.setFont(schriftart2);
		importbutton.setFont(schriftart2);
		exportbutton.setFont(schriftart2);
		//Komponenten ans Frame heften
		frame.add(tagesvbd);
		frame.add(jahresvbd);
		frame.add(zaehlerstandd);
		frame.add(importbutton);
		frame.add(exportbutton);
		frame.add(copyrighttext);
		frame.add(titel);
		//Position der Komponenten festlegen
		tagesvbd.setBounds(509, 115, 340, 75);
		jahresvbd.setBounds(505, 240, 340, 75);
		zaehlerstandd.setBounds(505, 370, 340, 75);
		importbutton.setBounds(100, 180, 230, 75);
		exportbutton.setBounds(100, 305, 230, 75);
		copyrighttext.setBounds(300, 535, 355, 25);
		titel.setBounds(110, 25, 750, 65);
		//ActionListener der Kn�pfe erstellen
		tagesvbd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (exception == true) {
					JOptionPane.showMessageDialog(frame,
							"Es wurden noch keine Daten importiert, deshalb funktioniert dieser Button noch nicht.",
							"Inane error", JOptionPane.ERROR_MESSAGE);
				} else {
					vm.openT_VerbrauchsGui();
				}
			}
		});
		jahresvbd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (exception == true) {
					JOptionPane.showMessageDialog(frame,
							"Es wurde noch nichts importiert. Deshalb funktioniert dieser Button noch nicht.",
							"Inane error", JOptionPane.ERROR_MESSAGE);
				} else {
					vm.openJ_VerbrauchsGui();
				}
			}
		});
		zaehlerstandd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (exception == true) {
					JOptionPane.showMessageDialog(frame,
							"Es wurde noch nichts importiert. Deshalb funktioniert dieser Button noch nicht.",
							"Inane error", JOptionPane.ERROR_MESSAGE);
				} else {
					vm.openZaehlerstandGui();
				}
			}
		});
		importbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(frame, "Das Importieren kann einige Minuten dauern");
				vm.setEslEinspeisen();
				vm.setEslBezogen();
				vm.setSdatBezogen();
				vm.setSdatEinspeisen();
				exception = false;
				JOptionPane.showMessageDialog(frame, "Das Importieren der Daten war erfolgreich.");
			}
		});
		exportbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (exception == true) {
					JOptionPane.showMessageDialog(frame,
							"Es wurde noch nichts importiert. Deshalb funktioniert dieser Button noch nicht.",
							"Inane error", JOptionPane.ERROR_MESSAGE);
				} else {
					vm.openExportierenGui();
				}
			}
		});
		frame.pack();
		frame.setResizable(false);
		frame.setVisible(true);
	}
}