package view;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import control.Manager;

/**
 * Dem Benutzer wird sein taeglicher Verbrauch an Strom, in Form eines
 * Diagrammes angezeigt. Der Benutzer waehlt im Kalender aus, fuer welchen Tag
 * er seinen Verbrauch sehen will. Die blaue Linie entspricht dem Verbrauch der
 * Einspesung und die rote Linie dem Bezug.
 */
public class J_VerbrauchsGui extends JFrame {

	// VARIABELN DEKLARIEREN
	private final JFrame frame = new JFrame();
	private final Manager vm;
	// Komponente
	private JPanel buttonPanel, diagrammPanel;
	private JButton zuruekButton;

	public J_VerbrauchsGui(JFrame frame, Manager vm) {
		// TODO Auto-generated constructor stub
		// instanzieren
		//this.frame = frame;
		this.vm = vm;
	}

	public void gui() {

		// Fensterdetails
		frame.setTitle("Jahresverbrauch");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// Groesse bei Minimierung des Fensters
		frame.setSize(944, 600);
		frame.setLayout(new BorderLayout(150, 100));

		zuruekButton = new JButton("Zur�ck");
		diagrammPanel = new JPanel();
		buttonPanel = new JPanel();

		// komponente den Panels zufuegen
		// Fenster
		buttonPanel.add(zuruekButton);
		JPanel panel1 = new JPanel();
		JPanel panel2 = new JPanel();
		JScrollPane pane = new JScrollPane(panel1);
		// Layouts setzen
		panel1.setLayout(new BorderLayout());
		panel2.setLayout(new BorderLayout(20, 0));
		// diagrammPanel.setLayout(new BorderLayout(0, 0));

		// Komponente den Panels zuf�gen
		panel2.add(diagrammPanel, BorderLayout.CENTER);
		panel1.add(panel2);

		// Komponente dem Fenster zufuegen
		frame.getContentPane().add(buttonPanel, BorderLayout.WEST);
		frame.getContentPane().add(pane, BorderLayout.CENTER);
		frame.getContentPane().add(new JPanel(), BorderLayout.EAST);

		frame.setResizable(false);
		frame.setVisible(true);

		zuruekButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				vm.openStartGui();
			}
		});
		// Komponente dem Fenster zufuegen
		this.initUI();
		frame.getContentPane().add(buttonPanel, BorderLayout.WEST);
		frame.getContentPane().add(pane, BorderLayout.CENTER);
		frame.getContentPane().add(new JPanel(), BorderLayout.EAST);

		frame.setResizable(false);
		frame.setVisible(true);
	}

	private void initUI() {
		XYDataset dataset = createDatasetJ();
		JFreeChart chart = createChartJ(dataset);
		ChartPanel chartPanel = new ChartPanel(chart);
		chartPanel.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));
		chartPanel.setBackground(Color.white);
		diagrammPanel.add(chartPanel);

		XYDataset dataset1 = createDatasetJa();
		JFreeChart chart1 = createChartJa(dataset1);
		ChartPanel chartPanel1 = new ChartPanel(chart1);
		chartPanel1.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));
		chartPanel1.setBackground(Color.white);
		diagrammPanel.add(chartPanel1);

		XYDataset dataset2 = createDatasetFe();
		JFreeChart chart2 = createChartFe(dataset2);
		ChartPanel chartPanel2 = new ChartPanel(chart2);
		chartPanel1.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));
		chartPanel1.setBackground(Color.white);
		diagrammPanel.add(chartPanel2);

		XYDataset dataset3 = createDatasetMae();
		JFreeChart chart3 = createChartMae(dataset3);
		ChartPanel chartPanel3 = new ChartPanel(chart3);
		chartPanel1.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));
		chartPanel1.setBackground(Color.white);
		diagrammPanel.add(chartPanel3);

		XYDataset dataset4 = createDatasetAp();
		JFreeChart chart4 = createChartAp(dataset4);
		ChartPanel chartPanel4 = new ChartPanel(chart4);
		chartPanel1.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));
		chartPanel1.setBackground(Color.white);
		diagrammPanel.add(chartPanel4);

		XYDataset dataset5 = createDatasetMai();
		JFreeChart chart5 = createChartMai(dataset5);
		ChartPanel chartPanel5 = new ChartPanel(chart5);
		chartPanel1.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));
		chartPanel1.setBackground(Color.white);
		diagrammPanel.add(chartPanel5);

		XYDataset dataset6 = createDatasetJun();
		JFreeChart chart6 = createChartJun(dataset6);
		ChartPanel chartPanel6 = new ChartPanel(chart6);
		chartPanel1.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));
		chartPanel1.setBackground(Color.white);
		diagrammPanel.add(chartPanel6);

		XYDataset dataset7 = createDatasetJul();
		JFreeChart chart7 = createChartJul(dataset7);
		ChartPanel chartPanel7 = new ChartPanel(chart7);
		chartPanel1.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));
		chartPanel1.setBackground(Color.white);
		diagrammPanel.add(chartPanel7);

		XYDataset dataset8 = createDatasetAu();
		JFreeChart chart8 = createChartAu(dataset8);
		ChartPanel chartPanel8 = new ChartPanel(chart8);
		chartPanel1.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));
		chartPanel1.setBackground(Color.white);
		diagrammPanel.add(chartPanel8);

		XYDataset dataset9 = createDatasetSe();
		JFreeChart chart9 = createChartSe(dataset9);
		ChartPanel chartPanel9 = new ChartPanel(chart9);
		chartPanel1.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));
		chartPanel1.setBackground(Color.white);
		diagrammPanel.add(chartPanel9);

		XYDataset dataset10 = createDatasetOk();
		JFreeChart chart10 = createChartOk(dataset10);
		ChartPanel chartPanel10 = new ChartPanel(chart10);
		chartPanel1.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));
		chartPanel1.setBackground(Color.white);
		diagrammPanel.add(chartPanel10);

		XYDataset dataset11 = createDatasetNo();
		JFreeChart chart11 = createChartNo(dataset11);
		ChartPanel chartPanel11 = new ChartPanel(chart11);
		chartPanel1.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));
		chartPanel1.setBackground(Color.white);
		diagrammPanel.add(chartPanel11);

		XYDataset dataset12 = createDatasetDe();
		JFreeChart chart12 = createChartDe(dataset12);
		ChartPanel chartPanel12 = new ChartPanel(chart12);
		chartPanel1.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));
		chartPanel1.setBackground(Color.white);
		diagrammPanel.add(chartPanel12);
	}

	private JFreeChart createChartJ(XYDataset dataset) {
		JFreeChart chart = ChartFactory.createXYLineChart("Jahres�bersicht", "Monat", "Verbrauch", dataset,
				PlotOrientation.VERTICAL, true, true, false);

		XYPlot plot = chart.getXYPlot();

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesStroke(0, new BasicStroke(2.0f));

		renderer.setSeriesPaint(1, Color.BLUE);
		renderer.setSeriesStroke(1, new BasicStroke(2.0f));

		plot.setRenderer(renderer);
		plot.setBackgroundPaint(Color.white);

		plot.setRangeGridlinesVisible(false);
		plot.setDomainGridlinesVisible(false);

		chart.getLegend().setFrame(BlockBorder.NONE);

		chart.setTitle(new TextTitle("Jahres�bersicht", new Font("Serif", Font.BOLD, 18)));

		return chart;
	}

	private XYDataset createDatasetJ() {
		XYSeries series1 = new XYSeries("Strom in das Stromnetz eingespiesen");
		for (int i = 0; i < 9; i++) {
			series1.add(i + 1, vm.getSdatDurchschnittMonateEinspeissen(i));
		}

		XYSeries series2 = new XYSeries("Strom vom Stromnetz bezogen");
		for (int i = 0; i < 9; i++) {
			series2.add(i + 1, vm.getSdatDurchschnittMonateBezug(i));
		}

		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(series1);
		dataset.addSeries(series2);

		return dataset;
	}

	private JFreeChart createChartJa(XYDataset dataset) {
		JFreeChart chart = ChartFactory.createXYLineChart("Januar", "Tag", "Verbrauch", dataset,
				PlotOrientation.VERTICAL, true, true, false);

		XYPlot plot = chart.getXYPlot();

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesStroke(0, new BasicStroke(2.0f));

		renderer.setSeriesPaint(1, Color.BLUE);
		renderer.setSeriesStroke(1, new BasicStroke(2.0f));

		plot.setRenderer(renderer);
		plot.setBackgroundPaint(Color.white);

		plot.setRangeGridlinesVisible(false);
		plot.setDomainGridlinesVisible(false);

		chart.getLegend().setFrame(BlockBorder.NONE);

		chart.setTitle(new TextTitle("Januar", new Font("Serif", Font.BOLD, 18)));

		return chart;
	}

	private XYDataset createDatasetJa() {
		XYSeries series1 = new XYSeries("Strom in das Stromnetz eingespiesen");
		for (int i = 0; i < 9; i++) {
			series1.add(i + 1, vm.getEinspeisenJanuar(i));
		}

		XYSeries series2 = new XYSeries("Strom vom Stromnetz bezogen");
		for (int i = 0; i < 9; i++) {
			series2.add(i + 1, vm.getBezugJanuar(i));
		}

		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(series1);
		dataset.addSeries(series2);

		return dataset;
	}

	private JFreeChart createChartFe(XYDataset dataset) {
		JFreeChart chart = ChartFactory.createXYLineChart("Februar", "Tag", "Verbrauch", dataset,
				PlotOrientation.VERTICAL, true, true, false);

		XYPlot plot = chart.getXYPlot();

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesStroke(0, new BasicStroke(2.0f));

		renderer.setSeriesPaint(1, Color.BLUE);
		renderer.setSeriesStroke(1, new BasicStroke(2.0f));

		plot.setRenderer(renderer);
		plot.setBackgroundPaint(Color.white);

		plot.setRangeGridlinesVisible(false);
		plot.setDomainGridlinesVisible(false);

		chart.getLegend().setFrame(BlockBorder.NONE);

		chart.setTitle(new TextTitle("Ferbruar", new Font("Serif", Font.BOLD, 18)));

		return chart;
	}

	private XYDataset createDatasetFe() {
		XYSeries series1 = new XYSeries("Strom in das Stromnetz eingespiesen");
		for (int i = 0; i < 9; i++) {
			series1.add(i + 1, vm.getEinspeisenFebruar(i));
		}

		XYSeries series2 = new XYSeries("Strom vom Stromnetz bezogen");
		for (int i = 0; i < 9; i++) {
			series2.add(i + 1, vm.getBezugFebruar(i));
		}

		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(series1);
		dataset.addSeries(series2);

		return dataset;
	}

	private JFreeChart createChartMae(XYDataset dataset) {
		JFreeChart chart = ChartFactory.createXYLineChart("M�rtz", "Tag", "Verbrauch", dataset,
				PlotOrientation.VERTICAL, true, true, false);

		XYPlot plot = chart.getXYPlot();

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesStroke(0, new BasicStroke(2.0f));

		renderer.setSeriesPaint(1, Color.BLUE);
		renderer.setSeriesStroke(1, new BasicStroke(2.0f));

		plot.setRenderer(renderer);
		plot.setBackgroundPaint(Color.white);

		plot.setRangeGridlinesVisible(false);
		plot.setDomainGridlinesVisible(false);

		chart.getLegend().setFrame(BlockBorder.NONE);

		chart.setTitle(new TextTitle("M�rtz", new Font("Serif", Font.BOLD, 18)));

		return chart;
	}

	private XYDataset createDatasetMae() {
		XYSeries series1 = new XYSeries("Strom in das Stromnetz eingespiesen");
		for (int i = 0; i < 9; i++) {
			series1.add(i + 1, vm.getEinspeisenMaerz(i));
		}

		XYSeries series2 = new XYSeries("Strom vom Stromnetz bezogen");
		for (int i = 0; i < 9; i++) {
			series2.add(i + 1, vm.getBezugMaerz(i));
		}

		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(series1);
		dataset.addSeries(series2);

		return dataset;
	}

	private JFreeChart createChartAp(XYDataset dataset) {
		JFreeChart chart = ChartFactory.createXYLineChart("April", "Tag", "Verbrauch", dataset,
				PlotOrientation.VERTICAL, true, true, false);

		XYPlot plot = chart.getXYPlot();

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesStroke(0, new BasicStroke(2.0f));

		renderer.setSeriesPaint(1, Color.BLUE);
		renderer.setSeriesStroke(1, new BasicStroke(2.0f));

		plot.setRenderer(renderer);
		plot.setBackgroundPaint(Color.white);

		plot.setRangeGridlinesVisible(false);
		plot.setDomainGridlinesVisible(false);

		chart.getLegend().setFrame(BlockBorder.NONE);

		chart.setTitle(new TextTitle("April", new Font("Serif", Font.BOLD, 18)));

		return chart;
	}

	private XYDataset createDatasetAp() {
		XYSeries series1 = new XYSeries("Strom in das Stromnetz eingespiesen");
		for (int i = 0; i < 9; i++) {
			series1.add(i + 1, vm.getEinspeisenApril(i));
		}

		XYSeries series2 = new XYSeries("Strom vom Stromnetz bezogen");
		for (int i = 0; i < 9; i++) {
			series2.add(i + 1, vm.getBezugApril(i));
		}

		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(series1);
		dataset.addSeries(series2);

		return dataset;
	}

	private JFreeChart createChartMai(XYDataset dataset) {
		JFreeChart chart = ChartFactory.createXYLineChart("Mai", "Tag", "Verbrauch", dataset, PlotOrientation.VERTICAL,
				true, true, false);

		XYPlot plot = chart.getXYPlot();

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesStroke(0, new BasicStroke(2.0f));

		renderer.setSeriesPaint(1, Color.BLUE);
		renderer.setSeriesStroke(1, new BasicStroke(2.0f));

		plot.setRenderer(renderer);
		plot.setBackgroundPaint(Color.white);

		plot.setRangeGridlinesVisible(false);
		plot.setDomainGridlinesVisible(false);

		chart.getLegend().setFrame(BlockBorder.NONE);

		chart.setTitle(new TextTitle("Mai", new Font("Serif", Font.BOLD, 18)));

		return chart;
	}

	private XYDataset createDatasetMai() {
		XYSeries series1 = new XYSeries("Strom in das Stromnetz eingespiesen");
		for (int i = 0; i < 9; i++) {
			series1.add(i + 1, vm.getEinspeisenMai(i));
		}

		XYSeries series2 = new XYSeries("Strom vom Stromnetz bezogen");
		for (int i = 0; i < 9; i++) {
			series2.add(i + 1, vm.getBezugMai(i));
		}

		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(series1);
		dataset.addSeries(series2);

		return dataset;
	}

	private JFreeChart createChartJun(XYDataset dataset) {
		JFreeChart chart = ChartFactory.createXYLineChart("Juni", "Tag", "Verbrauch", dataset, PlotOrientation.VERTICAL,
				true, true, false);

		XYPlot plot = chart.getXYPlot();

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesStroke(0, new BasicStroke(2.0f));

		renderer.setSeriesPaint(1, Color.BLUE);
		renderer.setSeriesStroke(1, new BasicStroke(2.0f));

		plot.setRenderer(renderer);
		plot.setBackgroundPaint(Color.white);

		plot.setRangeGridlinesVisible(false);
		plot.setDomainGridlinesVisible(false);

		chart.getLegend().setFrame(BlockBorder.NONE);

		chart.setTitle(new TextTitle("Juni", new Font("Serif", Font.BOLD, 18)));

		return chart;
	}

	private XYDataset createDatasetJun() {
		XYSeries series1 = new XYSeries("Strom in das Stromnetz eingespiesen");
		for (int i = 0; i < 9; i++) {
			series1.add(i + 1, vm.getEinspeisenJuni(i));
		}

		XYSeries series2 = new XYSeries("Strom vom Stromnetz bezogen");
		for (int i = 0; i < 9; i++) {
			series2.add(i + 1, vm.getBezugJuni(i));
		}

		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(series1);
		dataset.addSeries(series2);

		return dataset;
	}

	private JFreeChart createChartJul(XYDataset dataset) {
		JFreeChart chart = ChartFactory.createXYLineChart("Juli", "Tag", "Verbrauch", dataset, PlotOrientation.VERTICAL,
				true, true, false);

		XYPlot plot = chart.getXYPlot();

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesStroke(0, new BasicStroke(2.0f));

		renderer.setSeriesPaint(1, Color.BLUE);
		renderer.setSeriesStroke(1, new BasicStroke(2.0f));

		plot.setRenderer(renderer);
		plot.setBackgroundPaint(Color.white);

		plot.setRangeGridlinesVisible(false);
		plot.setDomainGridlinesVisible(false);

		chart.getLegend().setFrame(BlockBorder.NONE);

		chart.setTitle(new TextTitle("Juli", new Font("Serif", Font.BOLD, 18)));

		return chart;
	}

	private XYDataset createDatasetJul() {
		XYSeries series1 = new XYSeries("Strom in das Stromnetz eingespiesen");
		for (int i = 0; i < 9; i++) {
			series1.add(i + 1, vm.getEinspeisenJuli(i));
		}

		XYSeries series2 = new XYSeries("Strom vom Stromnetz bezogen");
		for (int i = 0; i < 9; i++) {
			series2.add(i + 1, vm.getBezugJuli(i));
		}

		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(series1);
		dataset.addSeries(series2);

		return dataset;
	}

	private JFreeChart createChartAu(XYDataset dataset) {
		JFreeChart chart = ChartFactory.createXYLineChart("August", "Tag", "Verbrauch", dataset,
				PlotOrientation.VERTICAL, true, true, false);

		XYPlot plot = chart.getXYPlot();

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesStroke(0, new BasicStroke(2.0f));

		renderer.setSeriesPaint(1, Color.BLUE);
		renderer.setSeriesStroke(1, new BasicStroke(2.0f));

		plot.setRenderer(renderer);
		plot.setBackgroundPaint(Color.white);

		plot.setRangeGridlinesVisible(false);
		plot.setDomainGridlinesVisible(false);

		chart.getLegend().setFrame(BlockBorder.NONE);

		chart.setTitle(new TextTitle("August", new Font("Serif", Font.BOLD, 18)));

		return chart;
	}

	private XYDataset createDatasetAu() {
		XYSeries series1 = new XYSeries("Strom in das Stromnetz eingespiesen");
		for (int i = 0; i < 9; i++) {
			series1.add(i + 1, vm.getEinspeisenAugust(i));
		}

		XYSeries series2 = new XYSeries("Strom vom Stromnetz bezogen");
		for (int i = 0; i < 9; i++) {
			series2.add(i + 1, vm.getBezugAugust(i));
		}

		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(series1);
		dataset.addSeries(series2);

		return dataset;
	}

	private JFreeChart createChartSe(XYDataset dataset) {
		JFreeChart chart = ChartFactory.createXYLineChart("September", "Tag", "Verbrauch", dataset,
				PlotOrientation.VERTICAL, true, true, false);

		XYPlot plot = chart.getXYPlot();

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesStroke(0, new BasicStroke(2.0f));

		renderer.setSeriesPaint(1, Color.BLUE);
		renderer.setSeriesStroke(1, new BasicStroke(2.0f));

		plot.setRenderer(renderer);
		plot.setBackgroundPaint(Color.white);

		plot.setRangeGridlinesVisible(false);
		plot.setDomainGridlinesVisible(false);

		chart.getLegend().setFrame(BlockBorder.NONE);

		chart.setTitle(new TextTitle("September", new Font("Serif", Font.BOLD, 18)));

		return chart;
	}

	private XYDataset createDatasetSe() {
		XYSeries series1 = new XYSeries("Strom in das Stromnetz eingespiesen");
		for (int i = 0; i < 9; i++) {
			series1.add(i + 1, vm.getEinspeisenSeptember(i));
		}

		XYSeries series2 = new XYSeries("Strom vom Stromnetz bezogen");
		for (int i = 0; i < 9; i++) {
			series2.add(i + 1, vm.getBezugSeptember(i));
		}

		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(series1);
		dataset.addSeries(series2);

		return dataset;
	}

	private JFreeChart createChartOk(XYDataset dataset) {
		JFreeChart chart = ChartFactory.createXYLineChart("Oktober", "Tag", "Verbrauch", dataset,
				PlotOrientation.VERTICAL, true, true, false);

		XYPlot plot = chart.getXYPlot();

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesStroke(0, new BasicStroke(2.0f));

		renderer.setSeriesPaint(1, Color.BLUE);
		renderer.setSeriesStroke(1, new BasicStroke(2.0f));

		plot.setRenderer(renderer);
		plot.setBackgroundPaint(Color.white);

		plot.setRangeGridlinesVisible(false);
		plot.setDomainGridlinesVisible(false);

		chart.getLegend().setFrame(BlockBorder.NONE);

		chart.setTitle(new TextTitle("Oktober", new Font("Serif", Font.BOLD, 18)));

		return chart;
	}

	private XYDataset createDatasetOk() {

		XYSeriesCollection dataset = new XYSeriesCollection();

		return dataset;
	}

	private JFreeChart createChartNo(XYDataset dataset) {
		JFreeChart chart = ChartFactory.createXYLineChart("November", "Tag", "Verbrauch", dataset,
				PlotOrientation.VERTICAL, true, true, false);

		XYPlot plot = chart.getXYPlot();

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesStroke(0, new BasicStroke(2.0f));

		renderer.setSeriesPaint(1, Color.BLUE);
		renderer.setSeriesStroke(1, new BasicStroke(2.0f));

		plot.setRenderer(renderer);
		plot.setBackgroundPaint(Color.white);

		plot.setRangeGridlinesVisible(false);
		plot.setDomainGridlinesVisible(false);

		chart.getLegend().setFrame(BlockBorder.NONE);

		chart.setTitle(new TextTitle("November", new Font("Serif", Font.BOLD, 18)));

		return chart;
	}

	private XYDataset createDatasetNo() {

		XYSeriesCollection dataset = new XYSeriesCollection();

		return dataset;
	}

	private JFreeChart createChartDe(XYDataset dataset) {
		JFreeChart chart = ChartFactory.createXYLineChart("Monats Verbrach", "Tag", "Verbrauch", dataset,
				PlotOrientation.VERTICAL, true, true, false);

		XYPlot plot = chart.getXYPlot();

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesStroke(0, new BasicStroke(2.0f));

		renderer.setSeriesPaint(1, Color.BLUE);
		renderer.setSeriesStroke(1, new BasicStroke(2.0f));

		plot.setRenderer(renderer);
		plot.setBackgroundPaint(Color.white);

		plot.setRangeGridlinesVisible(false);
		plot.setDomainGridlinesVisible(false);

		chart.getLegend().setFrame(BlockBorder.NONE);

		chart.setTitle(new TextTitle("Dezember", new Font("Serif", Font.BOLD, 18)));

		return chart;
	}

	private XYDataset createDatasetDe() {

		XYSeriesCollection dataset = new XYSeriesCollection();

		return dataset;
	}

	public static void main(String[] arguments) {
		J_VerbrauchsGui jvg = new J_VerbrauchsGui(new JFrame(), new Manager());
		jvg.gui();
	}
}