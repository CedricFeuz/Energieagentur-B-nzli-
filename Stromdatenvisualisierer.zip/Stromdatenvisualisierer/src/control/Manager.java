package control;

/**
 * @author Yara Fischer, Alexandra Wittwer
 * @date 02.10.19
 * @Version 1.0
 * 
 * Diese Klasse ist der Vermittler zwischen den Model- und den View-Klassen. Er holt Daten aus dem Model und �bergibt diese den Views
 */
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.TreeMap;

import javax.swing.JFrame;

import model.ESLListe;
import model.ExportDaten;
import model.SdatDaten;
import model.SdatListe;
import view.ErfolgGui;
import view.ExportierenGui;
import view.J_VerbrauchsGui;
import view.StartGui;
import view.T_VerbrauchsGui;
import view.ZaehlerstandGui;

public class Manager extends JFrame {

	// Model
	private ExportDaten export;
	private SdatListe sdatEinspeisen;
	private SdatListe sdatBezogen;
	private ESLListe eslEinspeisen;
	private ESLListe eslBezogen;

	// View
	private JFrame frame;
	private StartGui startGui;
	private ZaehlerstandGui zaehlerstandGui;
	private T_VerbrauchsGui t_VerbrauchsGui;
	private J_VerbrauchsGui j_VerbrauchsGui;
	private ExportierenGui exportierenGui;

	public Manager() {

		// Model
		sdatEinspeisen = new SdatListe();
		sdatBezogen = new SdatListe();
		eslBezogen = new ESLListe();
		eslEinspeisen = new ESLListe();

		// View
		frame = new JFrame();
		startGui = new StartGui(frame, this);
		zaehlerstandGui = new ZaehlerstandGui(frame, this);
		t_VerbrauchsGui = new T_VerbrauchsGui(frame, this);
		j_VerbrauchsGui = new J_VerbrauchsGui(frame, this);
		exportierenGui = new ExportierenGui(frame, this);
	}

	// Model
	/**
	 * Gibt den Wert an der Position index aus der Liste mit den ESL Eingespeister
	 * Strom Daten zur�ck.
	 * 
	 * @param index
	 * @return double
	 */
	public double getEslEinspeisen(int index) {
		return eslEinspeisen.getEinspeisen(index);
	}

	/**
	 * Gibt den Wert an der Position index aus der Liste mit den ESL Bezoger Strom
	 * Daten zur�ck.
	 * 
	 * @param index
	 * @return double
	 */
	public double getEslBezogen(int index) {

		return eslBezogen.getBezug(index);
	}

	/**
	 * Erstellt die Liste mit den ESL Eingespeister Strom Daten
	 */
	public void setEslEinspeisen() {
		eslEinspeisen.setListEinspeisen();
	}

	/**
	 * Erstellt die Liste mit den ESL Bezogeners Strom Daten
	 */
	public void setEslBezogen() {

		eslBezogen.setListBezug();
	}

	/**
	 * Gibt den Duchschnitt Wert von der Position index aus der Liste mit den Sdat
	 * Bezoger Strom Daten zur�ck.
	 * 
	 * @param index
	 * @return double
	 */
	public double getSdatDurchschnittMonateBezug(int index) {

		return sdatEinspeisen.getDurchschnittMonateBezug(index);
	}

	/**
	 * Gibt den Duchschnitt Wert von der Position index aus der Liste mit den Sdat
	 * Eingespeister Strom Daten zur�ck.
	 * 
	 * @param index
	 * @return double
	 */
	public double getSdatDurchschnittMonateEinspeissen(int index) {

		return sdatBezogen.getDurchschnittMonateBezug(index);
	}

	/**
	 * Erstellt die Liste mit den Sdat Eingespiester Strom Daten.
	 */
	public void setSdatEinspeisen() {

		sdatEinspeisen.setListEinspeisen();
	}

	/**
	 * Erstellt die Liste mit den Sdat Bezogener Strom Daten.
	 */
	public void setSdatBezogen() {

		sdatBezogen.setListBezug();
	}

	/**
	 * Gibt den Wert von der Position index aus der Liste mit den Sdat Eingespeister
	 * Strom Daten aus dem Monat Januar zur�ck.
	 * 
	 * @param index
	 * @return
	 */
	public double getEinspeisenJanuar(int index) {
		return sdatEinspeisen.getEinspeisenJanuar(index);
	}

	/**
	 * Gibt den Wert von der Position index aus der Liste mit den Sdat Eingespeister
	 * Strom Daten aus dem Monat Januar zur�ck.
	 * 
	 * @param index
	 * @return double
	 */
	public double getEinspeisenFebruar(int index) {
		return sdatEinspeisen.getEinspeisenFebruar(index);
	}

	/**
	 * Gibt den Wert von der Position index aus der Liste mit den Sdat Eingespeister
	 * Strom Daten aus dem Monat Januar zur�ck.
	 * 
	 * @param index
	 * @return double
	 */
	public double getEinspeisenMaerz(int index) {
		return sdatEinspeisen.getEinspeisenMaerz(index);
	}

	/**
	 * Gibt den Wert von der Position index aus der Liste mit den Sdat Eingespeister
	 * Strom Daten aus dem Monat Januar zur�ck.
	 * 
	 * @param index
	 * @return double
	 */
	public double getEinspeisenApril(int index) {
		return sdatEinspeisen.getEinspeisenApril(index);
	}

	/**
	 * Gibt den Wert von der Position index aus der Liste mit den Sdat Eingespeister
	 * Strom Daten aus dem Monat Januar zur�ck.
	 * 
	 * @param index
	 * @return double
	 */
	public double getEinspeisenMai(int index) {
		return sdatEinspeisen.getEinspeisenMai(index);
	}

	/**
	 * Gibt den Wert von der Position index aus der Liste mit den Sdat Eingespeister
	 * Strom Daten aus dem Monat Januar zur�ck.
	 * 
	 * @param index
	 * @return double
	 */
	public double getEinspeisenJuni(int index) {
		return sdatEinspeisen.getEinspeisenJuni(index);
	}

	/**
	 * Gibt den Wert von der Position index aus der Liste mit den Sdat Eingespeister
	 * Strom Daten aus dem Monat Januar zur�ck.
	 * 
	 * @param index
	 * @return double
	 */
	public double getEinspeisenJuli(int index) {
		return sdatEinspeisen.getEinspeisenJuni(index);
	}

	/**
	 * Gibt den Wert von der Position index aus der Liste mit den Sdat Eingespeister
	 * Strom Daten aus dem Monat Januar zur�ck.
	 * 
	 * @param index
	 * @return double
	 */
	public double getEinspeisenAugust(int index) {
		return sdatEinspeisen.getEinspeisenAugust(index);
	}

	public double getEinspeisenSeptember(int index) {
		return sdatEinspeisen.getEinspeisenSeptember(index);
	}

	/**
	 * Gibt den Wert von der Position index aus der Liste mit den Sdat Eingespeister
	 * Strom Daten aus dem Monat Januar zur�ck.
	 * 
	 * @param index
	 * @return double
	 */
	

	
	public double getBezugJanuar(int index) {
		return sdatBezogen.getBezugJanuar(index);
	}

	public double getBezugFebruar(int index) {
		return sdatBezogen.getBezugFebruar(index);
	}

	public double getBezugMaerz(int index) {
		return sdatBezogen.getBezugMaerz(index);
	}

	public double getBezugApril(int index) {
		return sdatBezogen.getBezugApril(index);
	}

	public double getBezugMai(int index) {
		return sdatBezogen.getBezugMai(index);
	}

	public double getBezugJuni(int index) {
		return sdatBezogen.getBezugJuni(index);
	}

	public double getBezugJuli(int index) {
		return sdatBezogen.getBezugJuli(index);
	}

	public double getBezugAugust(int index) {
		return sdatEinspeisen.getBezugAugust(index);
	}

	public double getBezugSeptember(int index) {
		return sdatBezogen.getBezugSeptember(index);
	}

	public TreeMap<Date, Double> getAlleMessungenBezug(Date date) {
		
		return sdatBezogen.getAlleMessungenBezug(date);
	}
	public TreeMap<Date, Double> getAlleMessungenEinspeisungen(Date date) {
		
		return sdatEinspeisen.getAlleMessungenEinspeisungen(date);
	}
	
	public void exportBezug() {
		export.exportBezug();
	}
	
	public void exportEinspeisung() {
		export.exportEinspeisung();
	}
	
	// View
	public void openStartGui() {
		startGui.gui();
	}

	public void openZaehlerstandGui() {
		zaehlerstandGui.gui();
	}

	public void openT_VerbrauchsGui() {
		t_VerbrauchsGui.gui();
	}

	public void openJ_VerbrauchsGui() {
		j_VerbrauchsGui.gui();
	}

	public void openExportierenGui() {
		exportierenGui.gui();
	}

}
