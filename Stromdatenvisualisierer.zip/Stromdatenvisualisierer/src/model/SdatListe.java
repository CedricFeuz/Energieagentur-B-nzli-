package model;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

public class SdatListe {
	TreeMap<Date, Double> alleMessungenBezug = new TreeMap<Date, Double>();
	TreeMap<Date, Double> alleMessungenEinspeisungen = new TreeMap<Date, Double>();
	
	private double[] einspeisenJanuar = new double[31];
	private double[] einspeisenFebruar = new double[28];
	private double[] einspeisenMaerz = new double[31];
	private double[] einspeisenApril = new double[30];
	private double[] einspeisenMai = new double[31];
	private double[] einspeisenJuni = new double[30];
	private double[] einspeisenJuli = new double[31];
	private double[] einspeisenAugust = new double[31];
	private double[] einspeisenSeptember = new double[30];
	
	private double[] bezugJanuar  = new double[31];
	private double[] bezugFebruar  = new double[28];
	private double[] bezugMaerz = new double[31];
	private double[] bezugApril = new double[30];
	private double[] bezugMai = new double[31];
	private double[] bezugJuni = new double[30];
	private double[] bezugJuli = new double[31];
	private double[] bezugAugust = new double[31];
	private double[] bezugSeptember = new double[30];

	private double[] durchschnittMonateBezug = new double[12];
	private double[] durchschnittMonateEinspeisung = new double[12];
	
	private Date januar = new Date(119, 0,1);
	private Date februar = new Date(119, 1,1);
	private Date maerz = new Date(119, 2,1);
	private Date april = new Date(119, 3,1);
	private Date mai = new Date(119, 4,1);
	private Date juni = new Date(119, 5,1);
	private Date juli = new Date(119, 6, 1);
	private Date august = new Date(119, 7,1);
	private Date september = new Date(119, 8,1);
	private Date oktober = new Date(119, 9,1);
	private Date november = new Date(119, 10,1);
	private Date dezember = new Date(119, 11,1);
	private SdatDaten wert;

	public SdatListe() {
		wert = new SdatDaten();
	}


	/**

	 * Diese Methode erstellt eine Liste mit allen Werten, welche Strom in das Stromnetz eingespiesen haben

	 */

	public void setListEinspeisen() {
		double durchschnitt = 0.0;
		boolean test = true;
		boolean test2 = false;
		for(int i = 0; i<31; i++) {
			einspeisenJanuar[i] = wert.getZaehlerstand(januar, test2);
			durchschnitt = + durchschnitt +  einspeisenJanuar[i];
			januar.setHours(januar.getHours() + 24);
		}
		januar = new Date(119, 0,1);
		durchschnitt = durchschnitt / 31;
		durchschnittMonateEinspeisung[0] = durchschnitt;
		durchschnitt = 0;
		for(int i = 0; i<28; i++) {
			einspeisenFebruar[i] = wert.getZaehlerstand(februar, test2);
			durchschnitt = + durchschnitt +  einspeisenFebruar[i];
			februar.setHours(februar.getHours() + 24);
		}
		februar = new Date(119, 1,1);
		durchschnitt = durchschnitt / 28;
		durchschnittMonateEinspeisung[1] = durchschnitt;
		for(int i = 0; i<31; i++) {
			einspeisenMaerz[i] = wert.getZaehlerstand(maerz, test2);
			durchschnitt = + durchschnitt +  einspeisenMaerz[i];
			maerz.setHours(maerz.getHours() + 24);
		}
		maerz = new Date(119, 2,1);
		durchschnitt = durchschnitt / 31;
		durchschnittMonateEinspeisung[2] = durchschnitt;
		durchschnitt = 0;
		for(int i = 0; i<30; i++) {
			einspeisenApril[i] = wert.getZaehlerstand(april, test2);
			durchschnitt = + durchschnitt + einspeisenApril[i];
			april.setHours(april.getHours() + 24);
		}
		april = new Date(119, 3,1);
		durchschnitt = durchschnitt / 30;
		durchschnittMonateEinspeisung[3] = durchschnitt;
		durchschnitt = 0;
		for(int i = 0; i<31; i++) {
			einspeisenMai[i] = wert.getZaehlerstand(mai, test2);
			durchschnitt = + durchschnitt +  einspeisenMai[i];
			mai.setHours(mai.getHours() + 24);
		}
		mai = new Date(119, 4,1);
		durchschnitt = durchschnitt / 31;
		durchschnittMonateEinspeisung[4] = durchschnitt;
		durchschnitt = 0;
		for(int i = 0; i<30; i++) {
			einspeisenJuni[i] = wert.getZaehlerstand(juni, test2);
			durchschnitt = + durchschnitt +  einspeisenJuni[i];
			juni.setHours(juni.getHours() + 24);
		}
		juni = new Date(119, 5,1);
		durchschnitt = durchschnitt / 30;
		durchschnittMonateEinspeisung[5] = durchschnitt;
		durchschnitt = 0;
		for(int i = 0; i<31; i++) {
			einspeisenJuli[i] = wert.getZaehlerstand(juli, test2);
			durchschnitt = + durchschnitt +  einspeisenJuli[i];
			juli.setHours(juli.getHours() + 24);
		}
		juli = new Date(119, 6,1);
		durchschnitt = durchschnitt / 31;
		durchschnittMonateEinspeisung[6] = durchschnitt;
		durchschnitt = 0;
		for(int i = 0; i<31; i++) {
			einspeisenAugust[i] = wert.getZaehlerstand(august, test2);
			durchschnitt = + durchschnitt +  einspeisenAugust[i];
			august.setHours(august.getHours() + 24);
		}
		august = new Date(119, 7,1);
		durchschnitt = durchschnitt / 31;
		durchschnittMonateEinspeisung[7] = durchschnitt;
		durchschnitt = 0;
		for(int i = 0; i<30; i++) {
			einspeisenSeptember[i] = wert.getZaehlerstand(september, test2);
			durchschnitt = + durchschnitt +  einspeisenSeptember[i];
			september.setHours(september.getHours() + 24);
		}
		september = new Date(119, 8,1);
		durchschnitt = durchschnitt / 30;
		durchschnittMonateEinspeisung[8] = durchschnitt;
	}

	public void setListAlleBezugMessungen(Date date, double wert) {
		alleMessungenBezug.put(date, wert);
	}
	
	public void setListAlleEinspeisungenMessungen(Date date, double wert) {
		alleMessungenEinspeisungen.put(date, wert);
	}

	public TreeMap<Date, Double> getAlleMessungenBezug(Date date) {
		TreeMap<Date, Double> tagesMessungenBezug = new TreeMap<Date, Double>();
		Set keys = alleMessungenBezug.keySet();
		   for (Iterator i = keys.iterator(); i.hasNext();) {
		     Date key = (Date) i.next();
		     Double value = alleMessungenBezug.get(key);
		     if(key.getMonth() == date.getMonth() && key.getDay() == date.getDay()) {
		    	 tagesMessungenBezug.put(key, value);
		     }
		   }
		return tagesMessungenBezug;
	}


	public TreeMap<Date, Double> getAlleMessungenEinspeisungen(Date date) {
		TreeMap<Date, Double> tagesMessungenEinspeisung = new TreeMap<Date, Double>();
		Set keys = alleMessungenBezug.keySet();
		   for (Iterator i = keys.iterator(); i.hasNext();) {
		     Date key = (Date) i.next();
		     Double value = alleMessungenEinspeisungen.get(key);
		     if(key.getMonth() == date.getMonth() && key.getDay() == date.getDay()) {
		    	 tagesMessungenEinspeisung.put(key, value);
		     }
		   }
		return tagesMessungenEinspeisung;
	}

	public void setListBezug() {
		double durchschnitt = 0.0;
		boolean test = true;
		boolean test2 = false;
		for(int i = 0; i<31; i++) {
			bezugJanuar[i] = wert.getZaehlerstand(januar, test);
			durchschnitt = + durchschnitt +  bezugJanuar[i];
			januar.setHours(januar.getHours() + 24);
		}
		januar = new Date(119, 0,1);
		durchschnitt = durchschnitt / 31;
		durchschnittMonateBezug[0] = durchschnitt;
		durchschnitt = 0;
		for(int i = 0; i<28; i++) {
			bezugFebruar[i] = wert.getZaehlerstand(februar, test);
			durchschnitt = + durchschnitt + bezugFebruar[i];
			februar.setHours(februar.getHours() + 24);
		}
		februar = new Date(119, 1,1);
		durchschnitt = durchschnitt / 28;
		durchschnittMonateBezug[1] = durchschnitt;
		durchschnitt = 0;
		for(int i = 0; i<31; i++) {
			bezugMaerz[i] = wert.getZaehlerstand(maerz, test);
			durchschnitt = + durchschnitt +  bezugMaerz[i];
			maerz.setHours(maerz.getHours() + 24);
		}
		maerz = new Date(119, 2,1);
		durchschnitt = durchschnitt / 31;
		durchschnittMonateBezug[2] = durchschnitt;
		durchschnitt = 0;
		for(int i = 0; i<30; i++) {
			bezugApril[i] = wert.getZaehlerstand(april, test);
			durchschnitt = + durchschnitt +  bezugApril[i];
			april.setHours(april.getHours() + 24);
		}
		april = new Date(119, 3,1);
		durchschnitt = durchschnitt / 30;
		durchschnittMonateBezug[3] = durchschnitt;
		durchschnitt = 0;
		for(int i = 0; i<31; i++) {
			bezugMai[i] = wert.getZaehlerstand(mai, test);
			durchschnitt = + durchschnitt +  bezugMai[i];
			mai.setHours(mai.getHours() + 24);
		}
		mai = new Date(119, 4,1);
		durchschnitt = durchschnitt / 31;
		durchschnittMonateBezug[4] = durchschnitt;
		durchschnitt = 0;
		for(int i = 0; i<30; i++) {
			bezugJuni[i] = wert.getZaehlerstand(juni, test);
			durchschnitt = + durchschnitt +  bezugJuni[i];
			juni.setHours(juni.getHours() + 24);
		}
		juni = new Date(119, 5,1);
		durchschnitt = durchschnitt / 30;
		durchschnittMonateBezug[5] = durchschnitt;
		durchschnitt = 0;
		for(int i = 0; i<31; i++) {
			bezugJuli[i] = wert.getZaehlerstand(juli, test);
			durchschnitt = + durchschnitt +  bezugJuli[i];
			juli.setHours(juli.getHours() + 24);
		}
		juli = new Date(119, 6,1);
		durchschnitt = durchschnitt / 31;
		durchschnittMonateBezug[6] = durchschnitt;
		durchschnitt = 0;
		for(int i = 0; i<31; i++) {
			bezugAugust[i] = wert.getZaehlerstand(august, test);
			durchschnitt = + durchschnitt +  bezugAugust[i];
			august.setHours(januar.getHours() + 24);
		}
		august = new Date(119, 7,1);
		durchschnitt = durchschnitt / 31;
		durchschnittMonateBezug[7] = durchschnitt;
		durchschnitt = 0;
		for(int i = 0; i<30; i++) {
			bezugSeptember[i] = wert.getZaehlerstand(september, test);
			durchschnitt = + durchschnitt +  bezugSeptember[i];
			september.setHours(september.getHours() + 24);
		}
		september = new Date(119, 8,1);
		durchschnitt = durchschnitt / 30;
		durchschnittMonateBezug[8] = durchschnitt;
	}


	public double getEinspeisenJanuar(int index) {
		return einspeisenJanuar[index];
	}


	public double getEinspeisenFebruar(int index) {
		return einspeisenFebruar[index];
	}


	public double getEinspeisenMaerz(int index) {
		return einspeisenMaerz[index];
	}


	public double getEinspeisenApril(int index) {
		return einspeisenApril[index];
	}


	public double getEinspeisenMai(int index) {
		return einspeisenMai[index];
	}


	public double getEinspeisenJuni(int index) {
		return einspeisenJuni[index];
	}


	public double getEinspeisenJuli(int index) {
		return einspeisenJuli[index];
	}


	public double getEinspeisenAugust(int index) {
		return einspeisenAugust[index];
	}


	public double getEinspeisenSeptember(int index) {
		return einspeisenSeptember[index];
	}


	public double getBezugJanuar(int index) {
		return bezugJanuar[index];
	}


	public double getBezugFebruar(int index) {
		return bezugFebruar[index];
	}


	public double getBezugMaerz(int index) {
		return bezugMaerz[index];
	}


	public double getBezugApril(int index) {
		return bezugApril[index];
	}


	public double getBezugMai(int index) {
		return bezugMai[index];
	}


	public double getBezugJuni(int index) {
		return bezugJuni[index];
	}


	public double getBezugJuli(int index) {
		return bezugJuli[index];
	}

	public double getBezugAugust(int index) {
		return bezugAugust[index];
	}


	public double getBezugSeptember(int index) {
		return bezugSeptember[index];
	}

	public double getDurchschnittMonateBezug(int index) {
		return durchschnittMonateBezug[index];
	}


	public double getDurchschnittMonateEinspeisung(int index) {
		return durchschnittMonateEinspeisung[index];
	}
	
}