package model;

import java.io.File;
import java.io.ObjectInputStream.GetField;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public class SdatDaten {

	//SdatListe liste = new SdatListe();

	public double getZaehlerstand(Date date, boolean test) {
		double zaehlerstand = 0.0;
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			File tests = new File("");
			String fi = tests.getAbsolutePath() + "\\XML-Files\\SDAT-Files";
			File dir = new File(fi);
			File[] fileList = dir.listFiles();
			loop: for (File f : fileList) {
				Document doc = builder.parse(f.getAbsolutePath());
				String s = doc.getElementsByTagName("rsm:StartDateTime").item(0).getTextContent();
				String month = s.substring(5, 7);
				int months = (int) month.charAt(1);
				months = months - 48;
				String day = s.substring(8, 10);
				int days = (int) day.charAt(1);
				days = days - 48;
				if (day.charAt(0) - 48 == 1) {
					days = days + 10;
				} else if (day.charAt(0) - 48 == 2) {
					days = days + 20;
				} else if (day.charAt(0) - 48 == 3) {
					days = days + 30;
				}
				Date dates = new Date(119, months - 1, days);
				if (date.equals(dates)) {
					if (test == true) {
						char c = doc.getElementsByTagName("rsm:DocumentID").item(0).getTextContent().charAt(24);
						if (c == '2') {
							String hourss = s.substring(11, 13);
							int hours = (int) day.charAt(1);
							hours = days - 48;
							if (hourss.charAt(0) - 48 == 1) {
								hours = hours + 10;
							} else if (hourss.charAt(0) - 48 == 2) {
								hours = hours + 20;
							}
							String minutess = s.substring(14, 16);
							int minutes = (int) day.charAt(1);
							minutes = minutes - 48;
							if (minutess.charAt(0) - 48 == 1) {
								minutes = minutes + 10;
							} else if (minutess.charAt(0) - 48 == 2) {
								minutes = minutes + 20;
							} else if (minutess.charAt(0) - 48 == 3) {
								minutes = minutes + 30;
							} else if (minutess.charAt(0) - 48 == 4) {
								minutes = minutes + 40;
							} else if (minutess.charAt(0) - 48 == 5) {
								minutes = minutes + 50;
							} else if (minutess.charAt(0) - 48 == 6) {
								minutes = minutes + 60;
							}
							Date zeit = new Date(119, months - 1, days - 1, hours, minutes);
							NodeList lists = doc.getElementsByTagName("rsm:Volume");
							for (int i = 0; i < lists.getLength(); i++) {
								String text = null;
								text = lists.item(i).getTextContent();
								double ds = Double.parseDouble(text);
								//liste.setListAlleBezugMessungen(zeit, ds);
								zeit.setMinutes(zeit.getMinutes() + 15);
								zaehlerstand = zaehlerstand + ds;
							}
							break loop;
						}
					} else {
						char c = doc.getElementsByTagName("rsm:DocumentID").item(0).getTextContent().charAt(24);
						if (c == '5') {
							String hourss = s.substring(11, 13);
							int hours = (int) day.charAt(1);
							hours = days - 48;
							if (hourss.charAt(0) - 48 == 1) {
								hours = hours + 10;
							} else if (hourss.charAt(0) - 48 == 2) {
								hours = hours + 20;
							}
							String minutess = s.substring(14, 16);
							int minutes = (int) day.charAt(1);
							minutes = minutes - 48;
							if (minutess.charAt(0) - 48 == 1) {
								minutes = minutes + 10;
							} else if (minutess.charAt(0) - 48 == 2) {
								minutes = minutes + 20;
							} else if (minutess.charAt(0) - 48 == 3) {
								minutes = minutes + 30;
							} else if (minutess.charAt(0) - 48 == 4) {
								minutes = minutes + 40;
							} else if (minutess.charAt(0) - 48 == 5) {
								minutes = minutes + 50;
							} else if (minutess.charAt(0) - 48 == 6) {
								minutes = minutes + 60;
							}
							Date zeit = new Date(119, months - 1, days - 1, hours, minutes);
							NodeList lists = doc.getElementsByTagName("rsm:Volume");
							for (int i = 0; i < lists.getLength(); i++) {
								String text = null;
								text = lists.item(i).getTextContent();
								double ds = Double.parseDouble(text);
								//liste.setListAlleEinspeisungenMessungen(zeit, ds);
								zeit.setMinutes(zeit.getMinutes() + 15);
								zaehlerstand = zaehlerstand + ds;
							}
							break loop;
						}
					}
				}
			}
		} catch (Exception e) {

		}
		zaehlerstand = zaehlerstand / 96;
		return zaehlerstand;
	}
}