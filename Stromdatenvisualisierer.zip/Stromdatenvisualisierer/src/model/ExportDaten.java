package model;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ExportDaten {
	ESLListe daten;
	String[] monate = { "Januar", "Februar", "maerz", "april", "mai", "juni", "juli", "august", "september", "oktober",
			"november", "dezember" };
	String t = "monat";
	double[] durchschnitte = { daten.getDurchschnittBezogen(), daten.getDurchschnittEinspeissen() };

	public void exportBezug() {
		String nameHomeVereichnis = System.getProperty("user.home");
		Path PfadMitDatei = Paths.get(nameHomeVereichnis, "bezug.csv");
		String v = "Bezug";
		String durchv = "DurchschnittBezug";
		daten.setListBezug();
		double[] bezug = { daten.getBezug(0), daten.getBezug(1), daten.getBezug(2), daten.getBezug(3),
				daten.getBezug(4), daten.getBezug(5), daten.getBezug(6), daten.getBezug(7), daten.getBezug(8),
				daten.getBezug(9), daten.getBezug(10), daten.getBezug(11) };
		try (BufferedWriter schreibpuffer = Files.newBufferedWriter(PfadMitDatei)) {
			String zeile1 = String.format("%s;%s%n", t, v);
			schreibpuffer.write(zeile1);
			for (int i = 0; i < 12; i++) {
				String zeile2 = String.format("%s;%s%n", monate[i], bezug[i]);
				schreibpuffer.write(zeile2);
			}
			String zeile5 = String.format("%s%n", "");
			schreibpuffer.write(zeile5);
			String zeile6 = String.format("%s%n", durchv);
			schreibpuffer.write(zeile6);
			String zeile7 = String.format("%f%n", durchschnitte[0]);
			schreibpuffer.write(zeile7);
		} catch (IOException ex) {

		}
	}

	public void exportEinspeisung() {
		double[] einspeisen = { daten.getEinspeisen(0), daten.getEinspeisen(1), daten.getEinspeisen(2),
				daten.getEinspeisen(3), daten.getEinspeisen(4), daten.getEinspeisen(5), daten.getEinspeisen(6),
				daten.getEinspeisen(7), daten.getEinspeisen(8), daten.getEinspeisen(9), daten.getEinspeisen(10),
				daten.getEinspeisen(11), };
		String durche = "DurchschnittEinspeisen";
		daten.setListEinspeisen();
		String e = "Einspeisen";
		String nameHomeVereichnis = System.getProperty("user.home");
		Path PfadMitDatei = Paths.get(nameHomeVereichnis, "einspeisung.csv");
		String zeile4 = String.format("%s%n", "");
		try (BufferedWriter schreibpuffer = Files.newBufferedWriter(PfadMitDatei)) {
			schreibpuffer.write(zeile4);
			String zeile3 = String.format("%s;%s%n", t, e);
			schreibpuffer.write(zeile3);
			for (int i = 0; i < 12; i++) {
				String zeile2 = String.format("%s;%s%n", monate[i], einspeisen[i]);
				schreibpuffer.write(zeile2);
			}
			String zeile5 = String.format("%s%n", "");
			schreibpuffer.write(zeile5);
			String zeile6 = String.format("%s%n", durche);
			schreibpuffer.write(zeile6);
			String zeile7 = String.format("%f%n", durchschnitte[1]);
			schreibpuffer.write(zeile7);
		} catch (IOException ex) {

		}
	}
}