package View;

import javax.swing.JFrame;

import Control.Manager;

public class ZaehlerstandGui {

	public ZaehlerstandGui(JFrame frame, Manager manager) {
		// TODO Auto-generated constructor stub
	}

	public void zaehlerstandGui() {
		// TODO Auto-generated method stub
		
	}

}
