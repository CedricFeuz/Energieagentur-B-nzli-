package Model;

import java.sql.Timestamp;

public class SdatDaten {

	public SdatDaten(double einspeisung) {
		// TODO Auto-generated constructor stub
	}

	public Timestamp getDatum(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isEinspeisen(Timestamp datum) {
		// TODO Auto-generated method stub
		return false;
	}

	public double getEinspeisung(Timestamp datum) {
		// TODO Auto-generated method stub
		return 0;
	}

	public double getBezug(Timestamp datum) {
		// TODO Auto-generated method stub
		return 0;
	}

}
