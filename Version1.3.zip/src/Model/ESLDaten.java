package Model;

import java.sql.Timestamp;
import java.util.Calendar;

public class ESLDaten {
 
	public ESLDaten(double d) {
		// TODO Auto-generated constructor stub
	}

	public Timestamp getDatum(int i) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public double getBezug(Timestamp timestamp) {
		// TODO Auto-generated method stub
		return 0.0;
	}

	public double getEinspeisung(Timestamp timestamp) {
		// TODO Auto-generated method stub
		return 0.0;
	}

	
	

}
